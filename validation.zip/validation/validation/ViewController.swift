//
//  ViewController.swift
//  validation
//
//  Created by MACOS on 6/19/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit


let REGEX_USER_NAME_LIMIT  = "^.{3,10}$"
let REGEX_USER_NAME  = "[A-Za-z0-9]{3,10}"
let REGEX_EMAIL  = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
let REGEX_PASSWORD_LIMIT  = "^.{6,20}$"
let REGEX_PASSWORD  = "[A-Za-z0-9]{6,20}"
let REGEX_PHONE_DEFAULT  = "[0-9]{10}"


class ViewController: UIViewController {

    @IBOutlet var txtname: TextFieldValidator!
    @IBOutlet var txtemail: TextFieldValidator!
    @IBOutlet var txtpwd: TextFieldValidator!
    @IBOutlet var txtmob: TextFieldValidator!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setvalidate()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func setvalidate() {
        txtname.addRegx(REGEX_USER_NAME, withMsg: "Nameshould be 3 to 10 character")
        txtname.presentInView = self.view
        
        txtemail.addRegx(REGEX_EMAIL, withMsg: "Email is wrong")
        txtemail.presentInView = self.view
        
        txtpwd.addRegx(REGEX_PASSWORD, withMsg: "Password should be 6 to 10")
        txtpwd.presentInView = self.view
        
        txtmob.addRegx(REGEX_PHONE_DEFAULT, withMsg: "Enter valid number")
        txtmob.presentInView = self.view
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnSubmit(_ sender: Any) {
        if txtname.validate() &&
           txtpwd.validate() &&
           txtemail.validate() &&
           txtmob.validate()
        {
            print("Success")
        }
    }

}

